"""
tests/conftest.py
-----------------
Shared fixtures used across the entire test suite.
All broker interactions are mocked — no network calls are made in tests.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
from unittest.mock import MagicMock

import pytest

from src.domain.signals import SignalSnapshot
from src.domain.types import AssetQuote, Symbol
from src.orchestration.cycle_snapshot import CycleSnapshot


# ---------------------------------------------------------------------------
# OSI symbol helpers
# ---------------------------------------------------------------------------

def make_leap_symbol(days_from_now: int = 400) -> str:
    """Return a valid OSI LEAP symbol expiring ~days_from_now days from today."""
    from datetime import timedelta
    expiry = (datetime.now() + timedelta(days=days_from_now)).strftime("%y%m%d")
    return f"SPY{expiry}C00600000"


def make_near_symbol(days_from_now: int = 30) -> str:
    """Return a valid OSI NEAR symbol expiring ~days_from_now days from today."""
    from datetime import timedelta
    expiry = (datetime.now() + timedelta(days=days_from_now)).strftime("%y%m%d")
    return f"SPY{expiry}C00700000"


# ---------------------------------------------------------------------------
# Position factories
# ---------------------------------------------------------------------------

def make_option_position(
    symbol: str,
    qty: float,
    asset_class: str = "us_option",
    underlying_symbol: Optional[str] = None,
    side: Optional[str] = None,
) -> Dict[str, Any]:
    """Build a minimal Alpaca-style position dict."""
    if side is None:
        side = "long" if qty > 0 else "short"
    return {
        "symbol":            symbol,
        "asset_class":       asset_class,
        "underlying_symbol": underlying_symbol,   # intentionally None to test OSI fallback
        "qty":               str(qty),
        "side":              side,
    }


# ---------------------------------------------------------------------------
# Open order factories
# ---------------------------------------------------------------------------

def make_mleg_order(
    order_id: str = "order-001",
    buy_symbol: str = "SPY270617C00605000",
    sell_symbol: str = "SPY260331C00714000",
    status: str = "accepted",
) -> Dict[str, Any]:
    """Build a completing PMCC MLEG open order (1 buy + 1 sell)."""
    return {
        "id":                order_id,
        "symbol":            "",
        "underlying_symbol": None,
        "order_class":       "mleg",
        "status":            status,
        "legs": [
            {"symbol": buy_symbol,  "side": "buy"},
            {"symbol": sell_symbol, "side": "sell"},
        ],
    }


def make_simple_order(
    order_id: str = "order-002",
    symbol: str = "SPY",
    underlying_symbol: str = "SPY",
    order_class: str = "simple",
    status: str = "accepted",
) -> Dict[str, Any]:
    """Build a simple (non-MLEG) open order."""
    return {
        "id":                order_id,
        "symbol":            symbol,
        "underlying_symbol": underlying_symbol,
        "order_class":       order_class,
        "status":            status,
        "legs":              [],
    }


# ---------------------------------------------------------------------------
# CycleSnapshot factory
# ---------------------------------------------------------------------------

def make_snapshot(
    equity: float = 100_000.0,
    option_buying_power: float = 50_000.0,
    positions: Optional[List[Dict[str, Any]]] = None,
    open_orders: Optional[List[Dict[str, Any]]] = None,
    option_chains: Optional[Dict[Tuple, List]] = None,
) -> CycleSnapshot:
    """Build a CycleSnapshot with sensible defaults for testing."""
    now = datetime.now(timezone.utc)
    return CycleSnapshot(
        _as_of_utc=now,
        _equity=equity,
        _option_buying_power=option_buying_power,
        _positions=positions or [],
        _open_orders=open_orders or [],
        _asset_quotes={Symbol("SPY"): AssetQuote(symbol="SPY", bid=688.0, ask=690.0, mid=689.0, timestamp_utc=None)},
        _option_chains=option_chains or {},
        _signals=SignalSnapshot.empty(as_of_utc=now),
    )


# ---------------------------------------------------------------------------
# Mock broker
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_broker():
    """A MagicMock that satisfies BrokerABC — no real HTTP calls."""
    broker = MagicMock()
    broker.get_account_snapshot.return_value = {
        "equity":                "100000.00",
        "options_buying_power":  "50000.00",
    }
    broker.get_positions.return_value  = []
    broker.get_open_orders.return_value = []
    broker.get_asset_quote.return_value = AssetQuote(
        symbol="SPY", bid=688.0, ask=690.0, mid=689.0, timestamp_utc=None,
    )
    broker.get_option_chain.return_value = []
    return broker
