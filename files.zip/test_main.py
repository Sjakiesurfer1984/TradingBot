"""
tests/test_main.py
-------------------
Tests for the wiring in main.py — verifies that the app assembles all its
components correctly without actually running cycles or making network calls.

What we verify:
- _build_broker() produces a broker using the registry
- _build_strategies() builds exactly one strategy per spec
- _build_risk_engine() registers the right evaluators with correct config
- PmccSizingConfig is populated from yaml config (not hardcoded)
- max_units flows from config into PmccIntentEvaluator
- equity_budget_pct does NOT appear anywhere in sizing config
"""
from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from src.app.main import _build_risk_engine, _build_strategies
from src.config.yaml_config import (
    AppConfig,
    GlobalRiskConfig,
    PmccConfig,
    PmccLeapConfig,
    PmccLiquidityConfig,
    PmccRiskConfig,
    PmccRollConfig,
    PmccShortConfig,
    StrategySpec,
)
from src.domain.intents import OptionIntentPayload, PmccIntentPayload
from src.risk.evaluators import OptionIntentEvaluator, PmccIntentEvaluator
from src.risk.pmcc_sizer import PmccSizer, PmccSizingConfig
from src.strategies.pmcc_strategy import PmccStrategy


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _make_pmcc_risk_config(
    max_buying_power_fraction: float = 0.50,
    max_debit_per_spread_usd: float  = 14_000.0,
    max_contracts_per_intent: int    = 1,
    slippage_factor: float           = 1.05,
) -> PmccRiskConfig:
    return PmccRiskConfig(
        max_buying_power_fraction=max_buying_power_fraction,
        max_debit_per_spread_usd=max_debit_per_spread_usd,
        max_contracts_per_intent=max_contracts_per_intent,
        slippage_factor=slippage_factor,
        ignore_spread_checks=False,
    )


def _make_pmcc_config(risk: PmccRiskConfig = None, max_units: int = 1) -> PmccConfig:
    return PmccConfig(
        underlying_symbol="SPY",
        max_units=max_units,
        leap=PmccLeapConfig(dte_min=365, dte_max=545, target_delta=0.80),
        short=PmccShortConfig(dte_min=21, dte_max=45, target_delta=0.20),
        roll=PmccRollConfig(dte_threshold=14, delta_threshold=0.35, profit_pct=0.50),
        liquidity=PmccLiquidityConfig(max_leap_spread_pct=0.10, max_near_spread_pct=0.10),
        risk=risk or _make_pmcc_risk_config(),
    )


def _make_app_config(pmcc_cfg: PmccConfig = None, enable_dedupe: bool = True) -> AppConfig:
    pmcc = pmcc_cfg or _make_pmcc_config()
    return AppConfig(
        config_path=Path("config/config.yaml"),
        default_dry_run=False,
        cycle_seconds=60.0,
        risk=GlobalRiskConfig(enable_open_order_dedupe=enable_dedupe),
        strategies=[StrategySpec(name="pmcc", config=pmcc)],
    )


# ---------------------------------------------------------------------------
# _build_strategies
# ---------------------------------------------------------------------------

class TestBuildStrategies:

    def test_builds_one_pmcc_strategy(self):
        cfg = _make_app_config()
        strategies = _build_strategies(cfg.strategies)
        assert len(strategies) == 1
        assert isinstance(strategies[0], PmccStrategy)

    def test_strategy_has_correct_underlying(self):
        cfg = _make_app_config()
        strategies = _build_strategies(cfg.strategies)
        assert strategies[0].config.underlying_symbol == "SPY"

    def test_strategy_has_correct_max_units(self):
        cfg = _make_app_config(pmcc_cfg=_make_pmcc_config(max_units=2))
        strategies = _build_strategies(cfg.strategies)
        assert strategies[0].config.max_units == 2

    def test_multiple_strategies_all_built(self):
        specs = [
            StrategySpec(name="pmcc", config=_make_pmcc_config()),
            StrategySpec(name="pmcc", config=_make_pmcc_config()),
        ]
        strategies = _build_strategies(specs)
        assert len(strategies) == 2


# ---------------------------------------------------------------------------
# _build_risk_engine — evaluator registration
# ---------------------------------------------------------------------------

class TestBuildRiskEngine:

    def test_pmcc_evaluator_registered(self):
        cfg = _make_app_config()
        engine = _build_risk_engine(cfg)
        assert PmccIntentPayload in engine._evaluators

    def test_option_evaluator_registered(self):
        cfg = _make_app_config()
        engine = _build_risk_engine(cfg)
        assert OptionIntentPayload in engine._evaluators

    def test_pmcc_evaluator_is_correct_type(self):
        cfg = _make_app_config()
        engine = _build_risk_engine(cfg)
        assert isinstance(engine._evaluators[PmccIntentPayload], PmccIntentEvaluator)

    def test_option_evaluator_is_correct_type(self):
        cfg = _make_app_config()
        engine = _build_risk_engine(cfg)
        assert isinstance(engine._evaluators[OptionIntentPayload], OptionIntentEvaluator)


# ---------------------------------------------------------------------------
# _build_risk_engine — sizing config flows from yaml, not hardcoded
# ---------------------------------------------------------------------------

class TestBuildRiskEngineSizingConfig:

    def _get_sizer(self, app_cfg: AppConfig) -> PmccSizer:
        engine = _build_risk_engine(app_cfg)
        evaluator: PmccIntentEvaluator = engine._evaluators[PmccIntentPayload]
        return evaluator.sizer

    def test_max_buying_power_fraction_from_config(self):
        risk = _make_pmcc_risk_config(max_buying_power_fraction=0.30)
        cfg  = _make_app_config(pmcc_cfg=_make_pmcc_config(risk=risk))
        sizer = self._get_sizer(cfg)
        assert sizer.config.max_buying_power_fraction == pytest.approx(0.30)

    def test_max_debit_per_spread_from_config(self):
        risk = _make_pmcc_risk_config(max_debit_per_spread_usd=20_000.0)
        cfg  = _make_app_config(pmcc_cfg=_make_pmcc_config(risk=risk))
        sizer = self._get_sizer(cfg)
        assert sizer.config.max_debit_per_spread_usd == pytest.approx(20_000.0)

    def test_max_contracts_from_config(self):
        risk = _make_pmcc_risk_config(max_contracts_per_intent=3)
        cfg  = _make_app_config(pmcc_cfg=_make_pmcc_config(risk=risk))
        sizer = self._get_sizer(cfg)
        assert sizer.config.max_contracts_per_intent == 3

    def test_slippage_factor_from_config(self):
        risk = _make_pmcc_risk_config(slippage_factor=1.10)
        cfg  = _make_app_config(pmcc_cfg=_make_pmcc_config(risk=risk))
        sizer = self._get_sizer(cfg)
        assert sizer.config.slippage_factor == pytest.approx(1.10)

    def test_no_equity_budget_in_sizing_config(self):
        """Equity must play NO role in sizing — verify the field doesn't exist."""
        cfg   = _make_app_config()
        sizer = self._get_sizer(cfg)
        assert not hasattr(sizer.config, "equity_budget_pct"), (
            "equity_budget_pct must not exist on PmccSizingConfig — "
            "sizing must be based on buying power only"
        )

    def test_max_units_flows_into_evaluator(self):
        cfg = _make_app_config(pmcc_cfg=_make_pmcc_config(max_units=3))
        engine = _build_risk_engine(cfg)
        evaluator: PmccIntentEvaluator = engine._evaluators[PmccIntentPayload]
        assert evaluator.max_units == 3


# ---------------------------------------------------------------------------
# _build_risk_engine — open order dedupe rule
# ---------------------------------------------------------------------------

class TestBuildRiskEngineDedupeRule:

    def test_dedupe_rule_present_when_enabled(self):
        from src.risk.rules.open_order_rule import OpenOrderDedupeRule
        cfg = _make_app_config(enable_dedupe=True)
        engine = _build_risk_engine(cfg)
        assert any(isinstance(r, OpenOrderDedupeRule) for r in engine.rules)

    def test_no_dedupe_rule_when_disabled(self):
        from src.risk.rules.open_order_rule import OpenOrderDedupeRule
        cfg = _make_app_config(enable_dedupe=False)
        engine = _build_risk_engine(cfg)
        assert not any(isinstance(r, OpenOrderDedupeRule) for r in engine.rules)
