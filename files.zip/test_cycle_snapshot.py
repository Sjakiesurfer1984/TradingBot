"""
tests/test_cycle_snapshot.py
-----------------------------
Tests for CycleSnapshot — the immutable data bag passed through every cycle.

What we verify:
- All accessors return copies, not references (callers can't mutate internal state)
- with_signals() produces a new snapshot without touching the original
- Defaults are correct types and values
"""
from __future__ import annotations

from datetime import datetime, timezone

import pytest

from src.domain.signals import RegimeLabel, SignalSnapshot
from src.domain.types import AssetQuote, Symbol
from src.orchestration.cycle_snapshot import CycleSnapshot

from tests.conftest import make_snapshot


class TestCycleSnapshotAccessors:

    def test_equity_returns_float(self):
        snap = make_snapshot(equity=123_456.78)
        assert snap.equity() == pytest.approx(123_456.78)
        assert isinstance(snap.equity(), float)

    def test_option_buying_power_returns_float(self):
        snap = make_snapshot(option_buying_power=25_000.0)
        assert snap.option_buying_power() == pytest.approx(25_000.0)

    def test_as_of_utc_is_datetime(self):
        snap = make_snapshot()
        assert isinstance(snap.as_of_utc(), datetime)
        assert snap.as_of_utc().tzinfo is not None  # must be timezone-aware

    def test_positions_returns_list_copy(self):
        pos = [{"symbol": "SPY260306C00715000", "qty": "-1"}]
        snap = make_snapshot(positions=pos)
        result = snap.positions()
        assert result == pos
        # Mutating the returned list must not affect the snapshot
        result.append({"symbol": "FAKE"})
        assert len(snap.positions()) == 1

    def test_open_orders_returns_list_copy(self):
        orders = [{"id": "abc", "order_class": "mleg"}]
        snap = make_snapshot(open_orders=orders)
        result = snap.open_orders()
        result.clear()
        assert len(snap.open_orders()) == 1

    def test_positions_empty_by_default(self):
        snap = make_snapshot()
        assert snap.positions() == []

    def test_open_orders_empty_by_default(self):
        snap = make_snapshot()
        assert snap.open_orders() == []

    def test_option_chains_returns_dict_copy(self):
        key = (Symbol("SPY"), "leaps")
        chains = {key: [{"contract_symbol": "SPY270617C00605000"}]}
        snap = make_snapshot(option_chains=chains)
        result = snap.option_chains()
        result.clear()
        assert len(snap.option_chains()) == 1

    def test_asset_quotes_present(self):
        snap = make_snapshot()
        quotes = snap.asset_quotes()
        assert Symbol("SPY") in quotes
        assert isinstance(quotes[Symbol("SPY")], AssetQuote)


class TestCycleSnapshotWithSignals:

    def test_with_signals_returns_new_instance(self):
        snap = make_snapshot()
        now = datetime.now(timezone.utc)
        new_signals = SignalSnapshot(
            as_of_utc=now,
            regime=RegimeLabel.BULL,
            regime_confidence=0.9,
        )
        updated = snap.with_signals(new_signals)
        assert updated is not snap  # new object

    def test_with_signals_updates_signals(self):
        snap = make_snapshot()
        now = datetime.now(timezone.utc)
        new_signals = SignalSnapshot(as_of_utc=now, regime=RegimeLabel.BEAR)
        updated = snap.with_signals(new_signals)
        assert updated.signals().regime == RegimeLabel.BEAR

    def test_with_signals_does_not_mutate_original(self):
        snap = make_snapshot()
        original_regime = snap.signals().regime
        now = datetime.now(timezone.utc)
        snap.with_signals(SignalSnapshot(as_of_utc=now, regime=RegimeLabel.BULL))
        assert snap.signals().regime == original_regime

    def test_with_signals_preserves_other_fields(self):
        snap = make_snapshot(equity=99_999.0)
        now = datetime.now(timezone.utc)
        updated = snap.with_signals(SignalSnapshot.empty(as_of_utc=now))
        assert updated.equity() == pytest.approx(99_999.0)
        assert updated.option_buying_power() == snap.option_buying_power()
        assert updated.positions() == snap.positions()
