"""
tests/test_orchestrator.py
---------------------------
Tests for TradingOrchestrator.run_cycle() — the top-level cycle coordinator.

What we verify:
- The two-phase snapshot build (pre-snapshot for chain requests, full snapshot with chains)
- Universe is collected from strategies and deduplicated
- Intents flow from strategies → risk engine → execution policy → broker
- dry_run=True suppresses order submission
- Order submission failures are caught and don't crash the cycle
- CycleRunResult counts are accurate
- Signal pipeline is called and its output attached to the snapshot
"""
from __future__ import annotations

from unittest.mock import MagicMock, call, patch

import pytest

from src.domain.intents import (
    IntentPayloadABC,
    PmccIntentPayload,
    SelectedOption,
    TradeIntent,
)
from src.domain.orders import OptionContract, OptionRight
from src.domain.signals import RegimeLabel, SignalSnapshot
from src.domain.types import OptionChainRequest, Symbol
from src.orchestration.orchestrator import TradingOrchestrator
from src.orchestration.orchestrator_interface import CycleRunResult
from src.risk.decisions import ApprovedIntent, RejectedIntent, RiskDecisionBatch

from tests.conftest import make_snapshot


# ---------------------------------------------------------------------------
# Helpers — minimal stubs
# ---------------------------------------------------------------------------

def _make_orchestrator(
    strategies=None,
    risk_decisions=None,
    orders=None,
    dry_run=False,
    chain_requests=None,
):
    """Build a TradingOrchestrator with all collaborators mocked."""
    broker = MagicMock()
    broker.submit_order.return_value = None

    snapshot = make_snapshot()

    snapshot_builder = MagicMock()
    snapshot_builder.build_snapshot.return_value = snapshot

    signal_pipeline = MagicMock()
    signal_pipeline.compute.return_value = SignalSnapshot.empty(
        as_of_utc=snapshot.as_of_utc()
    )

    risk_engine = MagicMock()
    risk_engine.evaluate.return_value = risk_decisions or RiskDecisionBatch(
        approved=[], rejected=[]
    )

    execution_policy = MagicMock()
    execution_policy.to_orders.return_value = orders or []

    strategy = MagicMock()
    strategy.get_symbols.return_value = [Symbol("SPY")]
    strategy.generate_intents.return_value = []
    # Not an OptionChainConsumerABC by default (isinstance check in orchestrator)
    strategy.__class__ = MagicMock  # ensure isinstance(strategy, OptionChainConsumerABC) is False

    return TradingOrchestrator(
        broker=broker,
        strategies=strategies if strategies is not None else [strategy],
        risk_engine=risk_engine,
        execution_policy=execution_policy,
        snapshot_builder=snapshot_builder,
        signal_pipeline=signal_pipeline,
        dry_run=dry_run,
    ), broker, snapshot_builder, risk_engine, execution_policy, signal_pipeline


# ---------------------------------------------------------------------------
# Two-phase snapshot build
# ---------------------------------------------------------------------------

class TestOrchestratorSnapshotPhases:

    def test_snapshot_builder_called_twice_per_cycle(self):
        orch, _, sb, _, _, _ = _make_orchestrator()
        orch.run_cycle()
        assert sb.build_snapshot.call_count == 2

    def test_first_snapshot_has_no_chain_requests(self):
        orch, _, sb, _, _, _ = _make_orchestrator()
        orch.run_cycle()
        first_call_kwargs = sb.build_snapshot.call_args_list[0].kwargs
        assert first_call_kwargs["option_chain_requests"] == []

    def test_second_snapshot_receives_chain_requests_from_strategies(self):
        """Strategies that implement OptionChainConsumerABC contribute chain requests."""
        from src.strategies.interfaces import OptionChainConsumerABC, StrategyABC
        from datetime import date

        req = OptionChainRequest(
            underlying="SPY", request_id="leaps",
            expiration_date_gte=date(2027, 1, 1),
            expiration_date_lte=date(2027, 8, 1),
        )

        class FakeStrategy(StrategyABC, OptionChainConsumerABC):
            def get_symbols(self): return [Symbol("SPY")]
            def generate_intents(self, snapshot): return []
            def get_option_chain_requests(self, snapshot): return [req]

        orch, _, sb, _, _, _ = _make_orchestrator(strategies=[FakeStrategy()])
        orch.run_cycle()
        second_call_kwargs = sb.build_snapshot.call_args_list[1].kwargs
        assert req in second_call_kwargs["option_chain_requests"]

    def test_signals_attached_to_both_snapshots(self):
        orch, _, sb, _, _, sp = _make_orchestrator()
        orch.run_cycle()
        sp.compute.assert_called_once()


# ---------------------------------------------------------------------------
# Universe collection
# ---------------------------------------------------------------------------

class TestOrchestratorUniverse:

    def test_universe_collected_from_all_strategies(self):
        s1, s2 = MagicMock(), MagicMock()
        s1.get_symbols.return_value = [Symbol("SPY")]
        s2.get_symbols.return_value = [Symbol("QQQ")]
        s1.generate_intents.return_value = []
        s2.generate_intents.return_value = []

        orch, _, sb, _, _, _ = _make_orchestrator(strategies=[s1, s2])
        orch.run_cycle()

        all_universes = [
            set(c.kwargs["universe"])
            for c in sb.build_snapshot.call_args_list
        ]
        # Both symbols must appear in each build call
        for u in all_universes:
            assert Symbol("SPY") in u
            assert Symbol("QQQ") in u

    def test_duplicate_symbols_deduplicated(self):
        s1, s2 = MagicMock(), MagicMock()
        s1.get_symbols.return_value = [Symbol("SPY")]
        s2.get_symbols.return_value = [Symbol("SPY")]  # same symbol
        s1.generate_intents.return_value = []
        s2.generate_intents.return_value = []

        orch, _, sb, _, _, _ = _make_orchestrator(strategies=[s1, s2])
        orch.run_cycle()

        universe = sb.build_snapshot.call_args_list[0].kwargs["universe"]
        assert universe.count(Symbol("SPY")) == 1


# ---------------------------------------------------------------------------
# Intent → risk → execution → submission flow
# ---------------------------------------------------------------------------

class TestOrchestratorIntentFlow:

    def test_intents_passed_to_risk_engine(self):
        intent = MagicMock(spec=TradeIntent)
        strategy = MagicMock()
        strategy.get_symbols.return_value = [Symbol("SPY")]
        strategy.generate_intents.return_value = [intent]

        orch, _, _, risk, _, _ = _make_orchestrator(strategies=[strategy])
        orch.run_cycle()

        risk.evaluate.assert_called_once()
        _, kwargs = risk.evaluate.call_args
        assert intent in kwargs["intents"]

    def test_approved_intents_passed_to_execution_policy(self):
        approved = ApprovedIntent(intent_id="x", approval_payload=MagicMock())
        decisions = RiskDecisionBatch(approved=[approved], rejected=[])

        orch, _, _, _, ep, _ = _make_orchestrator(risk_decisions=decisions)
        orch.run_cycle()

        ep.to_orders.assert_called_once_with(approvals=[approved])

    def test_orders_submitted_to_broker(self):
        order = MagicMock()
        approved = ApprovedIntent(intent_id="x", approval_payload=MagicMock())
        decisions = RiskDecisionBatch(approved=[approved], rejected=[])

        orch, broker, _, _, _, _ = _make_orchestrator(
            risk_decisions=decisions, orders=[order]
        )
        orch.run_cycle()
        broker.submit_order.assert_called_once_with(order)

    def test_result_counts_match_decisions(self):
        approved = [ApprovedIntent(intent_id=f"a{i}", approval_payload=MagicMock()) for i in range(2)]
        rejected = [RejectedIntent(intent_id="r1", reason="test")]
        decisions = RiskDecisionBatch(approved=approved, rejected=rejected)

        orch, _, _, _, _, _ = _make_orchestrator(
            risk_decisions=decisions, orders=[MagicMock(), MagicMock()]
        )
        result = orch.run_cycle()

        assert result.intents_approved == 2
        assert result.intents_rejected == 1
        assert result.orders_submitted == 2


# ---------------------------------------------------------------------------
# Dry run
# ---------------------------------------------------------------------------

class TestOrchestratorDryRun:

    def test_dry_run_suppresses_order_submission(self):
        order = MagicMock()
        approved = ApprovedIntent(intent_id="x", approval_payload=MagicMock())
        decisions = RiskDecisionBatch(approved=[approved], rejected=[])

        orch, broker, _, _, _, _ = _make_orchestrator(
            risk_decisions=decisions, orders=[order], dry_run=True
        )
        orch.run_cycle()
        broker.submit_order.assert_not_called()

    def test_dry_run_returns_zero_submitted(self):
        order = MagicMock()
        approved = ApprovedIntent(intent_id="x", approval_payload=MagicMock())
        decisions = RiskDecisionBatch(approved=[approved], rejected=[])

        orch, _, _, _, _, _ = _make_orchestrator(
            risk_decisions=decisions, orders=[order], dry_run=True
        )
        result = orch.run_cycle()
        assert result.orders_submitted == 0


# ---------------------------------------------------------------------------
# Submission failure handling
# ---------------------------------------------------------------------------

class TestOrchestratorSubmissionFailures:

    def test_failed_submission_does_not_crash_cycle(self):
        order = MagicMock()
        approved = ApprovedIntent(intent_id="x", approval_payload=MagicMock())
        decisions = RiskDecisionBatch(approved=[approved], rejected=[])

        orch, broker, _, _, _, _ = _make_orchestrator(
            risk_decisions=decisions, orders=[order]
        )
        broker.submit_order.side_effect = RuntimeError("network error")

        # Must not raise
        result = orch.run_cycle()
        assert result.orders_submitted == 0

    def test_partial_failure_counts_only_successful_submissions(self):
        o1, o2 = MagicMock(), MagicMock()
        approved = [
            ApprovedIntent(intent_id="a1", approval_payload=MagicMock()),
            ApprovedIntent(intent_id="a2", approval_payload=MagicMock()),
        ]
        decisions = RiskDecisionBatch(approved=approved, rejected=[])

        orch, broker, _, _, _, _ = _make_orchestrator(
            risk_decisions=decisions, orders=[o1, o2]
        )
        # First call succeeds, second fails
        broker.submit_order.side_effect = [None, RuntimeError("boom")]

        result = orch.run_cycle()
        assert result.orders_submitted == 1


# ---------------------------------------------------------------------------
# CycleRunResult structure
# ---------------------------------------------------------------------------

class TestCycleRunResult:

    def test_returns_cycle_run_result(self):
        orch, _, _, _, _, _ = _make_orchestrator()
        result = orch.run_cycle()
        assert isinstance(result, CycleRunResult)

    def test_zero_counts_when_nothing_happens(self):
        orch, _, _, _, _, _ = _make_orchestrator()
        result = orch.run_cycle()
        assert result.orders_submitted   == 0
        assert result.intents_generated  == 0
        assert result.intents_approved   == 0
        assert result.intents_rejected   == 0
