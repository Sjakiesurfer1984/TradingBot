"""
tests/test_cycle_snapshot_builder.py
--------------------------------------
Tests for CycleSnapshotBuilder — verifies it calls the broker correctly
and assembles the CycleSnapshot from the results.

Key invariants:
- get_account_snapshot() is called EXACTLY ONCE per build_snapshot() call
  (equity and buying power must not each trigger a separate /account call)
- equity and option_buying_power are read from the single account response
- positions and open_orders come from their respective broker calls
- option chains are fetched once per OptionChainRequest
- quotes are fetched once per universe symbol
"""
from __future__ import annotations

from datetime import date, datetime, timezone
from unittest.mock import MagicMock, call

import pytest

from src.domain.types import AssetQuote, OptionChainRequest, Symbol
from src.orchestration.cycle_snapshot_builder import CycleSnapshotBuilder

from tests.conftest import make_leap_symbol, make_near_symbol, make_option_position


class TestCycleSnapshotBuilderAccountFetch:

    def test_account_snapshot_called_exactly_once(self, mock_broker):
        """The single biggest regression guard: equity + bp must share one HTTP call."""
        builder = CycleSnapshotBuilder(broker=mock_broker)
        builder.build_snapshot(universe=[], option_chain_requests=[])
        mock_broker.get_account_snapshot.assert_called_once()

    def test_equity_read_from_account_snapshot(self, mock_broker):
        mock_broker.get_account_snapshot.return_value = {
            "equity": "123456.78",
            "options_buying_power": "0",
        }
        builder = CycleSnapshotBuilder(broker=mock_broker)
        snap = builder.build_snapshot(universe=[], option_chain_requests=[])
        assert snap.equity() == pytest.approx(123_456.78)

    def test_buying_power_read_from_account_snapshot(self, mock_broker):
        mock_broker.get_account_snapshot.return_value = {
            "equity": "0",
            "options_buying_power": "77994.30",
        }
        builder = CycleSnapshotBuilder(broker=mock_broker)
        snap = builder.build_snapshot(universe=[], option_chain_requests=[])
        assert snap.option_buying_power() == pytest.approx(77_994.30)

    def test_missing_equity_field_defaults_to_zero(self, mock_broker):
        mock_broker.get_account_snapshot.return_value = {"options_buying_power": "1000"}
        builder = CycleSnapshotBuilder(broker=mock_broker)
        snap = builder.build_snapshot(universe=[], option_chain_requests=[])
        assert snap.equity() == pytest.approx(0.0)

    def test_missing_buying_power_field_defaults_to_zero(self, mock_broker):
        mock_broker.get_account_snapshot.return_value = {"equity": "1000"}
        builder = CycleSnapshotBuilder(broker=mock_broker)
        snap = builder.build_snapshot(universe=[], option_chain_requests=[])
        assert snap.option_buying_power() == pytest.approx(0.0)


class TestCycleSnapshotBuilderPositions:

    def test_positions_passed_through(self, mock_broker):
        pos = [make_option_position(make_leap_symbol(), qty=2)]
        mock_broker.get_positions.return_value = pos
        builder = CycleSnapshotBuilder(broker=mock_broker)
        snap = builder.build_snapshot(universe=[], option_chain_requests=[])
        assert snap.positions() == pos

    def test_get_positions_called_once(self, mock_broker):
        builder = CycleSnapshotBuilder(broker=mock_broker)
        builder.build_snapshot(universe=[], option_chain_requests=[])
        mock_broker.get_positions.assert_called_once()

    def test_empty_positions(self, mock_broker):
        mock_broker.get_positions.return_value = []
        builder = CycleSnapshotBuilder(broker=mock_broker)
        snap = builder.build_snapshot(universe=[], option_chain_requests=[])
        assert snap.positions() == []


class TestCycleSnapshotBuilderOpenOrders:

    def test_open_orders_passed_through(self, mock_broker):
        orders = [{"id": "abc", "order_class": "mleg", "legs": []}]
        mock_broker.get_open_orders.return_value = orders
        builder = CycleSnapshotBuilder(broker=mock_broker)
        snap = builder.build_snapshot(universe=[], option_chain_requests=[])
        assert snap.open_orders() == orders

    def test_get_open_orders_called_once(self, mock_broker):
        builder = CycleSnapshotBuilder(broker=mock_broker)
        builder.build_snapshot(universe=[], option_chain_requests=[])
        mock_broker.get_open_orders.assert_called_once()


class TestCycleSnapshotBuilderQuotes:

    def test_quote_fetched_for_each_universe_symbol(self, mock_broker):
        universe = [Symbol("SPY"), Symbol("QQQ")]
        builder = CycleSnapshotBuilder(broker=mock_broker)
        builder.build_snapshot(universe=universe, option_chain_requests=[])
        assert mock_broker.get_asset_quote.call_count == 2

    def test_quotes_keyed_by_symbol(self, mock_broker):
        spy_quote = AssetQuote("SPY", bid=688.0, ask=690.0, mid=689.0, timestamp_utc=None)
        mock_broker.get_asset_quote.return_value = spy_quote
        builder = CycleSnapshotBuilder(broker=mock_broker)
        snap = builder.build_snapshot(universe=[Symbol("SPY")], option_chain_requests=[])
        assert Symbol("SPY") in snap.asset_quotes()

    def test_no_quotes_when_universe_empty(self, mock_broker):
        builder = CycleSnapshotBuilder(broker=mock_broker)
        snap = builder.build_snapshot(universe=[], option_chain_requests=[])
        mock_broker.get_asset_quote.assert_not_called()
        assert snap.asset_quotes() == {}


class TestCycleSnapshotBuilderOptionChains:

    def test_chain_fetched_per_request(self, mock_broker):
        mock_broker.get_option_chain.return_value = [{"contract_symbol": "SPY270617C00605000"}]
        requests = [
            OptionChainRequest(underlying="SPY", request_id="leaps",
                               expiration_date_gte=date(2027, 1, 1),
                               expiration_date_lte=date(2027, 8, 1)),
            OptionChainRequest(underlying="SPY", request_id="shorts",
                               expiration_date_gte=date(2026, 3, 1),
                               expiration_date_lte=date(2026, 4, 1)),
        ]
        builder = CycleSnapshotBuilder(broker=mock_broker)
        snap = builder.build_snapshot(universe=[], option_chain_requests=requests)
        assert mock_broker.get_option_chain.call_count == 2

    def test_chains_keyed_by_symbol_and_request_id(self, mock_broker):
        contracts = [{"contract_symbol": "SPY270617C00605000"}]
        mock_broker.get_option_chain.return_value = contracts
        requests = [
            OptionChainRequest(underlying="SPY", request_id="leaps",
                               expiration_date_gte=date(2027, 1, 1),
                               expiration_date_lte=date(2027, 8, 1)),
        ]
        builder = CycleSnapshotBuilder(broker=mock_broker)
        snap = builder.build_snapshot(universe=[], option_chain_requests=requests)
        key = (Symbol("SPY"), "leaps")
        assert key in snap.option_chains()
        assert snap.option_chains()[key] == contracts

    def test_no_chain_calls_when_no_requests(self, mock_broker):
        builder = CycleSnapshotBuilder(broker=mock_broker)
        builder.build_snapshot(universe=[], option_chain_requests=[])
        mock_broker.get_option_chain.assert_not_called()

    def test_snapshot_as_of_is_recent(self, mock_broker):
        before = datetime.now(timezone.utc)
        builder = CycleSnapshotBuilder(broker=mock_broker)
        snap = builder.build_snapshot(universe=[], option_chain_requests=[])
        after = datetime.now(timezone.utc)
        assert before <= snap.as_of_utc() <= after
