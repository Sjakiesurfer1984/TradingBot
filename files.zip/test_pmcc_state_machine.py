"""
tests/test_pmcc_state_machine.py
---------------------------------
Tests for PmccStateClassifier — the core state machine that decides what
the PMCC strategy should do each cycle.

State transitions tested:
  FLAT      — no positions, no pending orders
  LEAP_ONLY — long LEAP present, no short NEAR
  COVERED   — both LEAP and NEAR present
  NEAR_ONLY — short NEAR but no LEAP (illegal state)
  PENDING   — a completing MLEG open order exists

Also tests:
  - OSI fallback when underlying_symbol is None (the Alpaca bug we worked around)
  - Completing vs non-completing pending order distinction
  - _underlying_from_osi / _underlying_from_position helpers
  - DTE classification boundaries (>90 = LEAP, <=90 = NEAR)
"""
from __future__ import annotations

import pytest

from src.strategies.pmcc_state_machine import (
    PmccState,
    PmccStateClassifier,
    _underlying_from_osi,
    _underlying_from_position,
)
from tests.conftest import (
    make_leap_symbol,
    make_mleg_order,
    make_near_symbol,
    make_option_position,
    make_simple_order,
)


# ---------------------------------------------------------------------------
# Helper — short names for clarity inside tests
# ---------------------------------------------------------------------------

def classify(positions=None, open_orders=None, underlying="SPY"):
    return PmccStateClassifier().classify(
        underlying=underlying,
        positions=positions or [],
        open_orders=open_orders or [],
    )


# ---------------------------------------------------------------------------
# _underlying_from_osi
# ---------------------------------------------------------------------------

class TestUnderlyingFromOsi:

    def test_standard_spy_symbol(self):
        assert _underlying_from_osi("SPY270617C00605000") == "SPY"

    def test_multi_letter_underlying(self):
        assert _underlying_from_osi("AAPL260121C00150000") == "AAPL"

    def test_empty_string_returns_empty(self):
        assert _underlying_from_osi("") == ""

    def test_already_just_ticker(self):
        # Only alpha chars → returns the whole thing
        assert _underlying_from_osi("SPY") == "SPY"

    def test_lowercase_input_uppercased(self):
        assert _underlying_from_osi("spy270617c00605000") == "SPY"


# ---------------------------------------------------------------------------
# _underlying_from_position
# ---------------------------------------------------------------------------

class TestUnderlyingFromPosition:

    def test_uses_underlying_symbol_when_present(self):
        pos = {"symbol": "SPY270617C00605000", "underlying_symbol": "SPY"}
        assert _underlying_from_position(pos) == "SPY"

    def test_falls_back_to_osi_when_underlying_symbol_none(self):
        """This is the Alpaca bug: underlying_symbol is None on some responses."""
        pos = {"symbol": "SPY270617C00605000", "underlying_symbol": None}
        assert _underlying_from_position(pos) == "SPY"

    def test_falls_back_to_osi_when_underlying_symbol_missing(self):
        pos = {"symbol": "SPY260306C00715000"}
        assert _underlying_from_position(pos) == "SPY"

    def test_underlying_symbol_whitespace_stripped(self):
        pos = {"symbol": "SPY270617C00605000", "underlying_symbol": "  SPY  "}
        assert _underlying_from_position(pos) == "SPY"

    def test_underlying_symbol_lowercased_input(self):
        pos = {"symbol": "spy270617C00605000", "underlying_symbol": "spy"}
        assert _underlying_from_position(pos) == "SPY"


# ---------------------------------------------------------------------------
# FLAT state
# ---------------------------------------------------------------------------

class TestFlatState:

    def test_no_positions_no_orders_is_flat(self):
        result = classify()
        assert result.state == PmccState.FLAT

    def test_flat_has_no_leap_or_near(self):
        result = classify()
        assert result.leap_position is None
        assert result.near_position is None

    def test_non_option_positions_ignored(self):
        """Stock positions should not affect PMCC state."""
        pos = [{"symbol": "SPY", "asset_class": "us_equity", "qty": "100", "side": "long"}]
        result = classify(positions=pos)
        assert result.state == PmccState.FLAT

    def test_different_underlying_positions_ignored(self):
        pos = [make_option_position(make_leap_symbol(), qty=2)]
        result = classify(positions=pos, underlying="QQQ")
        assert result.state == PmccState.FLAT


# ---------------------------------------------------------------------------
# LEAP_ONLY state
# ---------------------------------------------------------------------------

class TestLeapOnlyState:

    def test_long_leap_no_near_is_leap_only(self):
        pos = [make_option_position(make_leap_symbol(400), qty=2)]
        result = classify(positions=pos)
        assert result.state == PmccState.LEAP_ONLY

    def test_leap_position_is_populated(self):
        sym = make_leap_symbol(400)
        pos = [make_option_position(sym, qty=2)]
        result = classify(positions=pos)
        assert result.leap_position is not None
        assert result.leap_position["symbol"] == sym

    def test_near_position_is_none(self):
        pos = [make_option_position(make_leap_symbol(400), qty=2)]
        result = classify(positions=pos)
        assert result.near_position is None

    def test_osi_fallback_correctly_classifies_leap(self):
        """underlying_symbol=None — must fall back to OSI parsing and still find the LEAP."""
        sym = make_leap_symbol(400)
        pos = [make_option_position(sym, qty=2, underlying_symbol=None)]
        result = classify(positions=pos)
        assert result.state == PmccState.LEAP_ONLY

    def test_short_long_leap_qty_string_parsed(self):
        """Alpaca returns qty as a string — must handle both int and str."""
        sym = make_leap_symbol(400)
        pos = [{"symbol": sym, "asset_class": "us_option",
                "underlying_symbol": None, "qty": "2", "side": "long"}]
        result = classify(positions=pos)
        assert result.state == PmccState.LEAP_ONLY


# ---------------------------------------------------------------------------
# COVERED state
# ---------------------------------------------------------------------------

class TestCoveredState:

    def test_leap_and_near_is_covered(self):
        pos = [
            make_option_position(make_leap_symbol(400), qty=2),
            make_option_position(make_near_symbol(30),  qty=-1),
        ]
        result = classify(positions=pos)
        assert result.state == PmccState.COVERED

    def test_both_positions_populated(self):
        leap_sym = make_leap_symbol(400)
        near_sym = make_near_symbol(30)
        pos = [
            make_option_position(leap_sym, qty=2),
            make_option_position(near_sym, qty=-1),
        ]
        result = classify(positions=pos)
        assert result.leap_position["symbol"] == leap_sym
        assert result.near_position["symbol"] == near_sym

    def test_covered_with_osi_fallback_both_legs(self):
        pos = [
            make_option_position(make_leap_symbol(400), qty=2,  underlying_symbol=None),
            make_option_position(make_near_symbol(30),  qty=-1, underlying_symbol=None),
        ]
        result = classify(positions=pos)
        assert result.state == PmccState.COVERED


# ---------------------------------------------------------------------------
# NEAR_ONLY state (illegal)
# ---------------------------------------------------------------------------

class TestNearOnlyState:

    def test_short_near_no_leap_is_near_only(self):
        pos = [make_option_position(make_near_symbol(30), qty=-1)]
        result = classify(positions=pos)
        assert result.state == PmccState.NEAR_ONLY

    def test_near_only_leap_is_none(self):
        pos = [make_option_position(make_near_symbol(30), qty=-1)]
        result = classify(positions=pos)
        assert result.leap_position is None
        assert result.near_position is not None


# ---------------------------------------------------------------------------
# PENDING state
# ---------------------------------------------------------------------------

class TestPendingState:

    def test_completing_mleg_order_is_pending(self):
        order = make_mleg_order()
        result = classify(open_orders=[order])
        assert result.state == PmccState.PENDING

    def test_non_completing_mleg_does_not_block(self):
        """An MLEG with 2 buys and no sell is NOT a completing PMCC entry."""
        order = {
            "id": "bad-order",
            "order_class": "mleg",
            "status": "accepted",
            "symbol": "",
            "underlying_symbol": None,
            "legs": [
                {"symbol": make_leap_symbol(), "side": "buy"},
                {"symbol": make_near_symbol(), "side": "buy"},  # two buys — not completing
            ],
        }
        result = classify(open_orders=[order])
        assert result.state == PmccState.FLAT

    def test_simple_order_does_not_block(self):
        """A simple (non-MLEG) order for SPY should not trigger PENDING."""
        order = make_simple_order(underlying_symbol="SPY", order_class="simple")
        result = classify(open_orders=[order])
        assert result.state == PmccState.FLAT

    def test_pending_beats_covered(self):
        """If a completing order exists alongside positions, PENDING wins."""
        pos = [
            make_option_position(make_leap_symbol(400), qty=2),
            make_option_position(make_near_symbol(30),  qty=-1),
        ]
        order = make_mleg_order()
        result = classify(positions=pos, open_orders=[order])
        assert result.state == PmccState.PENDING

    def test_completing_order_identified_via_legs(self):
        """MLEG orders have no top-level underlying_symbol — must check legs."""
        order = make_mleg_order(
            buy_symbol="SPY270617C00605000",
            sell_symbol="SPY260331C00714000",
        )
        result = classify(open_orders=[order])
        assert result.state == PmccState.PENDING

    def test_order_for_different_underlying_does_not_block(self):
        order = make_mleg_order(
            buy_symbol="QQQ270617C00500000",
            sell_symbol="QQQ260331C00600000",
        )
        result = classify(open_orders=[order], underlying="SPY")
        assert result.state == PmccState.FLAT


# ---------------------------------------------------------------------------
# DTE boundary — exactly 90 days
# ---------------------------------------------------------------------------

class TestDteBoundary:

    def test_exactly_91_dte_is_leap(self):
        sym = make_leap_symbol(days_from_now=91)
        pos = [make_option_position(sym, qty=1)]
        result = classify(positions=pos)
        assert result.leap_position is not None

    def test_exactly_90_dte_is_near(self):
        sym = make_near_symbol(days_from_now=90)
        pos = [make_option_position(sym, qty=-1)]
        result = classify(positions=pos)
        assert result.near_position is not None

    def test_short_position_with_high_dte_is_not_near(self):
        """A short option with DTE > 90 is not classified as a NEAR."""
        sym = make_leap_symbol(days_from_now=400)
        pos = [make_option_position(sym, qty=-1)]  # short but far out
        result = classify(positions=pos)
        assert result.near_position is None
        assert result.leap_position is None   # not a LEAP either (qty < 0)
        assert result.state == PmccState.FLAT
