from __future__ import annotations

from abc import ABC, abstractmethod

from TradingBot.orchestration.context import RiskContext
from TradingBot.domain.intents import TradeIntent
from TradingBot.domain.types import StrategyId


class StrategyABC(ABC):
    """
    Strategy contract (UML).

    A Strategy:
    - consumes a RiskContext snapshot
    - produces a list of TradeIntent objects
    - performs no broker IO
    """

    @property
    @abstractmethod
    def strategy_id(self) -> StrategyId:
        raise NotImplementedError

    @abstractmethod
    def generate_intents(self, ctx: RiskContext) -> list[TradeIntent]:
        raise NotImplementedError

