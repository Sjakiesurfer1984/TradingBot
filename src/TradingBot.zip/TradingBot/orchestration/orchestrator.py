# src/TradingBot/v2/orchestrator.py
#
# Orchestrator for Option C (UML compliant).
#
# Hard invariants (UML note)
# - Only Orchestrator calls BrokerABC.
# - Strategies never submit orders.
# - RiskEngine is sole authority on sizing/allocation.

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, List

from TradingBot.brokers.account_snapshot import AccountSnapshot
from TradingBot.brokers.broker_interface import BrokerABC
from TradingBot.domain.intents import TradeIntent
from TradingBot.orchestration.context import RiskContext
from TradingBot.risk.decisions import RiskDecision
from TradingBot.risk.price_policy import DefaultPriceSelectionPolicy, PriceSelectionPolicy
from TradingBot.risk.risk_engine import RiskEngineABC
from TradingBot.strategies.strategy_interface import StrategyABC
from TradingBot.utilities.logger import setup_logger
from TradingBot.utilities.logging_utils import log_scope

logger = setup_logger("Orchestrator")


@dataclass
class Orchestrator:
    """
    Orchestrator.

    UML contract
    - broker : BrokerABC
    - strategies : list<StrategyABC>
    - risk_engine : RiskEngineABC
    - run_cycle() : None

    Runtime contract
    - This class owns all broker IO.
    - It builds one RiskContext snapshot per cycle.
    - It calls strategies (pure) to generate intents.
    - It calls risk engine (pure) to evaluate intents into decisions.
    - It submits approved orders only when dry_run is False.
    """

    broker: BrokerABC
    strategies: List[StrategyABC]
    risk_engine: RiskEngineABC
    dry_run: bool = True

    # Policy is pure computation. Injected for testability.
    price_policy: PriceSelectionPolicy = DefaultPriceSelectionPolicy()

    def _now_utc(self) -> datetime:
        return datetime.now(timezone.utc)

    def _build_risk_context(self) -> RiskContext:
        """
        Build the RiskContext snapshot for this cycle.

        This method performs broker IO, because the orchestrator is the IO boundary.
        """
        with log_scope("orchestrator._build_risk_context", logger):
            as_of_utc: datetime = self._now_utc()
            logger.info("Building RiskContext as_of_utc=%s", as_of_utc.isoformat())

            with log_scope("broker.get_account_snapshot", logger):
                account_snapshot: AccountSnapshot = self.broker.get_account_snapshot()

            with log_scope("broker.get_open_orders", logger):
                open_orders_any: Any = self.broker.get_open_orders()

            with log_scope("broker.get_positions", logger):
                positions_any: Any = self.broker.get_positions()

            option_buying_power_raw: Any = getattr(account_snapshot, "options_buying_power", None)
            equity_raw: Any = getattr(account_snapshot, "equity", None)

            option_buying_power: float = float(option_buying_power_raw) if isinstance(option_buying_power_raw, (int, float)) else 0.0
            equity: float = float(equity_raw) if isinstance(equity_raw, (int, float)) else 0.0

            open_orders: List[Dict[str, Any]] = []
            if isinstance(open_orders_any, list):
                open_orders = [x for x in open_orders_any if isinstance(x, dict)]

            positions: List[Dict[str, Any]] = []
            if isinstance(positions_any, list):
                positions = [x for x in positions_any if isinstance(x, dict)]

            logger.info(
                "Broker snapshot | option_buying_power=%.2f equity=%.2f open_orders=%d positions=%d",
                float(option_buying_power),
                float(equity),
                int(len(open_orders)),
                int(len(positions)),
            )

            # UML RiskContext includes prices and option_chains.
            # If your RiskContext requires these fields, we provide empty dicts for now.
            ctx: RiskContext = RiskContext(
                as_of_utc=as_of_utc,
                option_buying_power=option_buying_power,
                equity=equity,
                positions=positions,
                open_orders=open_orders,
                prices={},          # no quote fetching in UML orchestrator
                option_chains={},   # no chain fetching in UML orchestrator
                price_policy=self.price_policy,
            )

            return ctx

    def _collect_intents(self, ctx: RiskContext) -> List[TradeIntent]:
        """
        Call every strategy to generate intents (pure, no IO).
        """
        with log_scope("orchestrator._collect_intents", logger):
            all_intents: List[TradeIntent] = []

            for strat in self.strategies:
                try:
                    with log_scope(
                        "strategy.generate_intents",
                        logger,
                        extra=f"strategy_id={getattr(strat, 'strategy_id', '<unknown>')}",
                    ):
                        intents: List[TradeIntent] = strat.generate_intents(ctx)
                except Exception as exc:
                    logger.exception("Strategy failed to generate intents | strategy_id=%s error=%s", getattr(strat, "strategy_id", "<unknown>"), str(exc))
                    continue

                logger.info("Strategy produced intents | strategy_id=%s count=%d", strat.strategy_id, int(len(intents)))
                all_intents.extend(intents)

            logger.info("Total intents collected=%d", int(len(all_intents)))
            return all_intents

    def _evaluate_intents(self, ctx: RiskContext, intents: List[TradeIntent]) -> List[RiskDecision]:
        """
        Evaluate intents using the risk engine (pure, no IO).
        """
        with log_scope("orchestrator._evaluate", logger, extra=f"intents={len(intents)}"):
            decisions: List[RiskDecision] = self.risk_engine.evaluate(ctx, intents)
            logger.info("Risk engine decisions count=%d", int(len(decisions)))
            return decisions

    def _submit(self, decisions: List[RiskDecision]) -> None:
        """
        Submit approved orders (IO).
        """
        with log_scope("orchestrator._submit", logger, extra=f"decisions={len(decisions)}"):
            for decision in decisions:
                approved = getattr(decision, "approved", None)
                if approved is None:
                    continue

                order = getattr(approved, "order", None)
                client_order_id = getattr(approved, "client_order_id", None)

                try:
                    with log_scope("broker.submit_order", logger, extra=f"client_order_id={client_order_id}"):
                        resp: Any = self.broker.submit_order(order)
                    logger.info("Order submitted | client_order_id=%s response=%s", client_order_id, resp)
                except Exception as exc:
                    logger.exception("Order submit failed | client_order_id=%s error=%s", client_order_id, str(exc))

    def run_cycle(self) -> None:
        """
        Run one orchestrator cycle (UML public method).

        Flow (UML)
        - build_risk_context()
        - collect_intents(ctx)
        - evaluate(ctx, intents)
        - submit(decisions) unless dry_run
        """
        with log_scope("orchestrator.run_cycle", logger):
            ctx: RiskContext = self._build_risk_context()
            intents: List[TradeIntent] = self._collect_intents(ctx)
            decisions: List[RiskDecision] = self._evaluate(ctx, intents)

            if self.dry_run:
                logger.info("Dry run enabled: skipping order submission.")
                return

            self._submit(decisions)
