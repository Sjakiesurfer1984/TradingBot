from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime, timezone
from typing import Any, Dict, List, Set, Tuple

from TradingBot.brokers.broker_interface import BrokerABC
from TradingBot.domain.signals import SignalSnapshot
from TradingBot.domain.types import AssetQuote, OptionChainRequest, Symbol, normalise_symbol
from TradingBot.orchestration.cycle_snapshot import CycleSnapshot, CycleSnapshotABC
from TradingBot.risk.price_policy import DefaultPriceSelectionPolicy, PriceSelectionPolicy
from TradingBot.signals.default_signal_pipeline import DefaultSignalPipeline
from TradingBot.signals.signal_pipeline_interface import SignalPipelineABC
from TradingBot.utilities.logger import setup_logger
from TradingBot.utilities.logging_utils import log_scope

logger = setup_logger("CycleSnapshotBuilder")


class CycleSnapshotBuilderABC(ABC):
    @abstractmethod
    def build_snapshot(
        self,
        *,
        universe: Set[Symbol],
        option_chain_requests: List[OptionChainRequest],
    ) -> CycleSnapshotABC:
        raise NotImplementedError


class CycleSnapshotBuilder(CycleSnapshotBuilderABC):
    """
    Builds the immutable per-cycle snapshot.

    Contract
    - All broker IO happens here (or in broker calls it invokes).
    - Strategy code reads only from CycleSnapshotABC (pure, no IO).
    - Signals are computed after IO and attached to the snapshot.
    """

    def __init__(
        self,
        *,
        broker: BrokerABC,
        price_policy: PriceSelectionPolicy | None = None,
        signal_pipeline: SignalPipelineABC | None = None,
    ) -> None:
        self._broker: BrokerABC = broker
        self._price_policy: PriceSelectionPolicy = price_policy or DefaultPriceSelectionPolicy()
        self._signal_pipeline: SignalPipelineABC = signal_pipeline or DefaultSignalPipeline()

    def build_snapshot(
        self,
        *,
        universe: Set[Symbol],
        option_chain_requests: List[OptionChainRequest],
    ) -> CycleSnapshotABC:
        as_of_utc: datetime = datetime.now(tz=timezone.utc)

        with log_scope(
            "snapshot.build_snapshot",
            logger,
            extra=f"universe={len(universe)} option_chain_requests={len(option_chain_requests)}",
        ):
            # Account / portfolio state (execution side)
            _account: Dict[str, Any] = self._broker.get_account_snapshot()
            option_buying_power: float = float(self._broker.get_option_buying_power())
            equity: float = float(self._broker.get_equity())
            positions: List[Dict[str, Any]] = list(self._broker.get_positions())
            open_orders: List[Dict[str, Any]] = list(self._broker.get_open_orders())

            # Market data (quotes)
            asset_quotes: Dict[Symbol, AssetQuote] = {}
            for sym in sorted(universe, key=lambda s: str(s)):
                asset_quotes[sym] = self._broker.get_asset_quote(sym)

            # Option chains (keyed by (underlying_symbol, request_id))
            option_chains: Dict[Tuple[Symbol, str], List[Dict[str, Any]]] = {}
            for req in option_chain_requests:
                underlying_sym: Symbol = normalise_symbol(str(req.underlying).strip().upper())
                chain: List[Dict[str, Any]] = self._broker.get_option_chain(req)
                option_chains[(underlying_sym, str(req.request_id))] = chain

            # Create snapshot with empty signals first, then attach computed signals.
            snapshot: CycleSnapshot = CycleSnapshot(
                _as_of_utc=as_of_utc,
                _option_buying_power=option_buying_power,
                _equity=equity,
                _positions=positions,
                _open_orders=open_orders,
                _asset_quotes=asset_quotes,
                _option_chains=option_chains,
                _price_policy=self._price_policy,
                _signals=SignalSnapshot.empty(),
            )

            signals: SignalSnapshot = self._signal_pipeline.build(snapshot)
            return snapshot.with_signals(signals)
