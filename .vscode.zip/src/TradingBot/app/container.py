from __future__ import annotations

from dataclasses import dataclass

from TradingBot.config.env_config import EnvConfig, load_env_config
from TradingBot.config.yaml_config import AppConfig, load_app_config


@dataclass(frozen=True)
class SettingsRuntime:
    env_cfg: EnvConfig
    app_cfg: AppConfig


def build_settings_runtime() -> SettingsRuntime:
    env_cfg = load_env_config()
    app_cfg = load_app_config()
    return SettingsRuntime(env_cfg=env_cfg, app_cfg=app_cfg)
