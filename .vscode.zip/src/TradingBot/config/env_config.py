from __future__ import annotations

from dataclasses import dataclass
import os


@dataclass(frozen=True)
class EnvConfig:
    broker_name: str
    alpaca_mode: str
    alpaca_key: str
    alpaca_secret: str


def load_env_config() -> EnvConfig:
    broker_name = os.getenv("TRADINGBOT_BROKER", "alpaca").strip().lower()
    alpaca_mode = os.getenv("ALPACA_MODE", "paper").strip().lower()

    if alpaca_mode == "paper":
        alpaca_key = os.getenv("ALPACA_PAPER_API_KEY", "")
        alpaca_secret = os.getenv("ALPACA_PAPER_API_SECRET", "")
    else:
        alpaca_key = os.getenv("ALPACA_LIVE_API_KEY", "")
        alpaca_secret = os.getenv("ALPACA_LIVE_API_SECRET", "")

    return EnvConfig(
        broker_name=broker_name,
        alpaca_mode=alpaca_mode,
        alpaca_key=alpaca_key,
        alpaca_secret=alpaca_secret,
    )
