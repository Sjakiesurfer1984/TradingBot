from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict

import yaml


@dataclass(frozen=True)
class AppConfig:
    config_path: Path
    default_dry_run: bool
    cycle_seconds: float
    raw: Dict[str, Any]


def load_app_config() -> AppConfig:
    repo_root = Path(__file__).resolve().parents[3]
    config_path = repo_root / "config" / "config.yaml"

    if not config_path.exists():
        raise FileNotFoundError(f"Config not found: {config_path}")

    with config_path.open("r", encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}

    return AppConfig(
        config_path=config_path,
        default_dry_run=bool(raw.get("default_dry_run", True)),
        cycle_seconds=float(raw.get("cycle_seconds", 60)),
        raw=raw,
    )
